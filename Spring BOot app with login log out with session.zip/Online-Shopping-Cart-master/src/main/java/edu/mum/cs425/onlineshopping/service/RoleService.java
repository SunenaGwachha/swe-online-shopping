package edu.mum.cs425.onlineshopping.service;

import java.util.List;

import edu.mum.cs425.onlineshopping.entity.Role;

public interface RoleService {
	
	public List<Role> getRoles();

}
